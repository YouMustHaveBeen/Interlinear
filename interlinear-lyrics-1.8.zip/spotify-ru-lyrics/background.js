// Фоновый скрипт: ищет темп (BPM) трека в базе GetSongBPM.
// Ключ API хранится в chrome.storage.local (поле gsbKey), результаты кэшируются.

const clean = (s) =>
  s
    .replace(/\s*[\(\[][^)\]]*(remaster|feat|live|version|mix|edit|deluxe|bonus)[^)\]]*[\)\]]/gi, "")
    .replace(/\s+-\s+(remaster(ed)?.*|live.*|.*version|.*mix|.*edit)$/i, "")
    .trim();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "bpm") {
    lookup(msg.title, msg.artist)
      .then(sendResponse)
      .catch(() => sendResponse({ status: "error" }));
    return true; // ответ придёт позже
  }
});

async function lookup(title, artist) {
  const store = await chrome.storage.local.get(["gsbKey", "bpmCache"]);
  const key = store.gsbKey;
  if (!key) return { status: "nokey" };

  const cache = store.bpmCache || {};
  const id = (artist + "|" + title).toLowerCase();
  if (cache[id]) return cache[id];

  const firstArtist = artist.split(",")[0].trim();
  const url =
    "https://api.getsongbpm.com/search/?api_key=" +
    encodeURIComponent(key) +
    "&type=both&lookup=" +
    encodeURIComponent("song:" + clean(title) + " artist:" + firstArtist);

  const r = await fetch(url);
  if (r.status === 401 || r.status === 403) return { status: "badkey" };
  if (!r.ok) return { status: "error" };

  const data = await r.json();
  if (data && typeof data.error === "string" && /key|auth/i.test(data.error)) {
    return { status: "badkey" };
  }

  const list = data && Array.isArray(data.search) ? data.search : [];
  const nameOf = (a) => (Array.isArray(a) ? a[0] && a[0].name : a && a.name) || "";
  const want = firstArtist.toLowerCase();
  const pick = list.find((x) => nameOf(x.artist).toLowerCase().includes(want));
  const tempo = pick ? parseInt(pick.tempo, 10) : 0;

  const result = tempo
    ? { status: "ok", tempo, time_sig: pick.time_sig || "" }
    : { status: "none" };

  cache[id] = result;
  await chrome.storage.local.set({ bpmCache: cache });
  return result;
}
