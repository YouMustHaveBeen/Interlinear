// Фоновый скрипт: ищет темп (BPM) трека в базе SonoVault по названию и исполнителю.
// Ключ API хранится в chrome.storage.local (поле svKey), найденные темпы кэшируются.

const clean = (s) =>
  s
    .replace(/\s*[\(\[][^)\]]*(remaster|feat|live|version|mix|edit|deluxe|bonus)[^)\]]*[\)\]]/gi, "")
    .replace(/\s+-\s+(remaster(ed)?.*|live.*|.*version|.*mix|.*edit)$/i, "")
    .trim();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "bpm") {
    lookup(msg.title, msg.artist)
      .then(sendResponse)
      .catch(() => sendResponse({ status: "error" }));
    return true; // ответ придёт позже
  }
});

// Ответ может быть одним треком или списком: берём первый подходящий.
function candidates(data) {
  if (!data) return [];
  if (Array.isArray(data)) return data;
  for (const k of ["results", "tracks", "data", "items", "track"]) {
    if (Array.isArray(data[k])) return data[k];
    if (data[k] && typeof data[k] === "object") return [data[k]];
  }
  return typeof data === "object" ? [data] : [];
}

function artistNames(t) {
  const a = t && (t.artists || t.artist);
  if (!a) return [];
  const list = Array.isArray(a) ? a : [a];
  return list.map((x) => (typeof x === "string" ? x : (x && x.name) || "")).filter(Boolean);
}

async function lookup(title, artist) {
  const store = await chrome.storage.local.get(["svKey", "bpmCache"]);
  const key = store.svKey;
  if (!key) return { status: "nokey" };

  const cache = store.bpmCache || {};
  const id = (artist + "|" + title).toLowerCase();
  if (cache[id]) return cache[id];

  const firstArtist = artist.split(",")[0].trim();
  const url =
    "https://api.sonovault.now/v1/tracks/search?artist=" +
    encodeURIComponent(firstArtist) +
    "&title=" +
    encodeURIComponent(clean(title));

  const r = await fetch(url, { headers: { "x-api-key": key } });
  if (r.status === 401) return { status: "badkey" };
  if (r.status === 403) {
    let text = "";
    try { text = JSON.stringify(await r.json()); } catch (e) { text = ""; }
    return { status: /verif/i.test(text) ? "unverified" : "badkey" };
  }
  if (r.status === 404) return { status: "none" };
  if (r.status === 429) return { status: "limit" };
  if (!r.ok) return { status: "error" };

  const data = await r.json();
  const want = firstArtist.toLowerCase();
  const matches = (t) => {
    const names = artistNames(t).map((n) => n.toLowerCase());
    return names.length === 0 || names.some((n) => n.includes(want) || want.includes(n));
  };
  const pick = candidates(data).find((t) => t && matches(t) && t.bpm != null);
  const bpm = pick ? Math.round(Number(pick.bpm)) : 0;

  if (!bpm) return { status: "none" };

  const result = { status: "ok", tempo: bpm };
  cache[id] = result;
  await chrome.storage.local.set({ bpmCache: cache });
  return result;
}
